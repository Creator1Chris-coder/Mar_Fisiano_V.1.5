package com.cevicheria.app;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ProductoForm {

    private MenuManager menuManager;

    public ProductoForm() {
        this.menuManager = new MenuManager();
    }

    public void crearFormularioProducto() {
        JFrame frame = new JFrame("Gestión de Producto");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel nombreLabel = new JLabel("Nombre:");
        JTextField nombreField = new JTextField(20);
        JLabel categoriaLabel = new JLabel("Categoría:");
        JTextField categoriaField = new JTextField(20);
        JLabel precioLabel = new JLabel("Precio:");
        JTextField precioField = new JTextField(20);
        JLabel descripcionLabel = new JLabel("Descripción:");
        JTextArea descripcionArea = new JTextArea(3, 20);
        JLabel disponibleLabel = new JLabel("Disponible:");
        JCheckBox disponibleCheckbox = new JCheckBox();

        JButton guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String categoriaNombre = categoriaField.getText();
                Double precio = Double.parseDouble(precioField.getText());
                String descripcion = descripcionArea.getText();
                Boolean disponible = disponibleCheckbox.isSelected();

                Categoria categoria = new Categoria();
                categoria.setNombre(categoriaNombre);
                menuManager.crearProducto(nombre, categoria, precio, descripcion, disponible);

                JOptionPane.showMessageDialog(frame, "Producto guardado exitosamente!");
            }
        });

        frame.add(nombreLabel);
        frame.add(nombreField);
        frame.add(categoriaLabel);
        frame.add(categoriaField);
        frame.add(precioLabel);
        frame.add(precioField);
        frame.add(descripcionLabel);
        frame.add(descripcionArea);
        frame.add(disponibleLabel);
        frame.add(disponibleCheckbox);
        frame.add(guardarButton);

        frame.setVisible(true);
    }
}