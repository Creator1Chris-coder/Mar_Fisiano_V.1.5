package com.cevicheria.app;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

public class MenuManager {
    private EntityManager em;

    public MenuManager() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public void crearProducto(String nombre, Categoria categoria, Double precio, String descripcion, Boolean disponible) {
        em.getTransaction().begin();
        Producto producto = new Producto();
        producto.setNombre(nombre);
        producto.setCategoria(categoria);
        producto.setPrecio(precio);
        producto.setDescripcion(descripcion);
        producto.setDisponible(disponible);
        em.persist(producto);
        em.getTransaction().commit();
    }

    public void actualizarProducto(Long id, String nombre, Categoria categoria, Double precio, String descripcion, Boolean disponible) {
        em.getTransaction().begin();
        Producto producto = em.find(Producto.class, id);
        producto.setNombre(nombre);
        producto.setCategoria(categoria);
        producto.setPrecio(precio);
        producto.setDescripcion(descripcion);
        producto.setDisponible(disponible);
        em.merge(producto);
        em.getTransaction().commit();
    }

    public void eliminarProducto(Long id) {
        em.getTransaction().begin();
        Producto producto = em.find(Producto.class, id);
        if (producto != null) {
            em.remove(producto);
        }
        em.getTransaction().commit();
    }
}
