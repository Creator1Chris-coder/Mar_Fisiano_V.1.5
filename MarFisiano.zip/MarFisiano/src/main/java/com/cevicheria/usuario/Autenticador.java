package com.cevicheria.usuario;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.Persistence;

public class Autenticador {
    private EntityManager em;

    public Autenticador() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public boolean autenticarUsuario(String username, String password) {
        try {
            Usuario usuario = em.createQuery("SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password", Usuario.class)
                                 .setParameter("username", username)
                                 .setParameter("password", password)
                                 .getSingleResult();
            return usuario != null;
        } catch (NoResultException e) {
            return false;
        }
    }
}
