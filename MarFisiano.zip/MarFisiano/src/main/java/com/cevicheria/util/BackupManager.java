package com.cevicheria.util;

import java.io.*;
import java.nio.file.*;

public class BackupManager {

    public void realizarBackup() {
        Path source = Paths.get("src/resources/backup/database.db"); // Ruta al archivo de base de datos
        Path destination = Paths.get("src/resources/backup/database_backup.db"); // Ruta de destino

        try {
            Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Backup realizado exitosamente.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error al realizar el backup.");
        }
    }
}
