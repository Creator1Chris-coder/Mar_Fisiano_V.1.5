package com.cevicheria.pedido;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

public class PedidoManager {

    private EntityManager em;

    public PedidoManager() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public void crearPedido(Pedido pedido) {
        em.getTransaction().begin();
        em.persist(pedido);
        em.getTransaction().commit();
    }

    public void actualizarEstadoPedido(Long idPedido, String estado) {
        em.getTransaction().begin();
        Pedido pedido = em.find(Pedido.class, idPedido);
        if (pedido != null) {
            pedido.setEstado(estado);
            em.merge(pedido);
        }
        em.getTransaction().commit();
    }
}
