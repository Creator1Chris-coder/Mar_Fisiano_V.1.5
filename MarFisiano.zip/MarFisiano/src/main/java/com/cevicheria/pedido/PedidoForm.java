package com.cevicheria.pedido;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.cevicheria.usuario.Cliente;
import com.cevicheria.app.Producto;

public class PedidoForm {

    private PedidoManager pedidoManager;

    public PedidoForm() {
        this.pedidoManager = new PedidoManager();
    }

    public void crearFormularioPedido() {
        JFrame frame = new JFrame("Toma de Pedido");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel clienteLabel = new JLabel("Cliente:");
        JTextField clienteField = new JTextField(20);

        JLabel productoLabel = new JLabel("Producto:");
        JTextField productoField = new JTextField(20);

        JLabel cantidadLabel = new JLabel("Cantidad:");
        JTextField cantidadField = new JTextField(5);

        JButton agregarButton = new JButton("Agregar Producto");
        JButton guardarButton = new JButton("Guardar Pedido");

        List<DetallePedido> detalles = new ArrayList<>();

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cliente = clienteField.getText();  
                String productoNombre = productoField.getText(); 
                int cantidad = Integer.parseInt(cantidadField.getText());  

                Producto producto = new Producto();
                producto.setNombre(productoNombre);  

                DetallePedido detalle = new DetallePedido();
                detalle.setProducto(producto);  
                detalle.setCantidad(cantidad);  

                detalles.add(detalle);
                JOptionPane.showMessageDialog(frame, "Producto agregado al pedido.");
            }
        });

        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pedido pedido = new Pedido();

                // Crear cliente a partir del nombre ingresado
                Cliente cliente = new Cliente();
                cliente.setNombre(clienteField.getText());
                pedido.setCliente(cliente);  // ← Ahora es un Cliente, no un String

                pedido.setDetalles(detalles);  
                pedidoManager.crearPedido(pedido); 

                JOptionPane.showMessageDialog(frame, "Pedido guardado exitosamente.");
            }
        });

        frame.add(clienteLabel);
        frame.add(clienteField);
        frame.add(productoLabel);
        frame.add(productoField);
        frame.add(cantidadLabel);
        frame.add(cantidadField);
        frame.add(agregarButton);
        frame.add(guardarButton);

        frame.setVisible(true);
    }
}
