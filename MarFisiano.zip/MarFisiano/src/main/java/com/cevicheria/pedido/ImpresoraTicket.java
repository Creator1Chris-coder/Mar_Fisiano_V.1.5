package com.cevicheria.pedido;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.Copies;

public class ImpresoraTicket {

    public void imprimirTicket(Pedido pedido) {
        try {
            PrintService printService = PrintServiceLookup.lookupDefaultPrintService();
            if (printService != null) {
                DocPrintJob printJob = printService.createPrintJob();
                StringBuilder ticketContent = new StringBuilder();

                ticketContent.append("***** TICKET CEVICHERIA *****\n");
                ticketContent.append("Pedido ID: ").append(pedido.getId()).append("\n");
                ticketContent.append("Estado: ").append(pedido.getEstado()).append("\n");

                for (DetallePedido detalle : pedido.getDetalles()) {
                    ticketContent.append(detalle.getProducto().getNombre())
                                 .append(" - Cantidad: ").append(detalle.getCantidad())
                                 .append(" - Notas: ").append(detalle.getNotas()).append("\n");
                }

                ticketContent.append("\n**** FIN DEL TICKET ****");

                Doc doc = new SimpleDoc(ticketContent.toString().getBytes(), DocFlavor.BYTE_ARRAY.AUTOSENSE, null);
                PrintRequestAttributeSet attributes = new HashPrintRequestAttributeSet();
                attributes.add(new Copies(1));
                printJob.print(doc, attributes);

                System.out.println("Ticket impreso exitosamente.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
