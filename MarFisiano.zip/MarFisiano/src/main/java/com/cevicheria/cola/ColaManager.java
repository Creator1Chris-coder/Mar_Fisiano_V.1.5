package com.cevicheria.cola;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

import com.cevicheria.pedido.Pedido;

public class ColaManager {
    private EntityManager em;

    public ColaManager() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public List<Pedido> obtenerPedidosEnCola() {
        return em.createQuery("SELECT p FROM Pedido p WHERE p.estado = 'En espera'", Pedido.class)
                 .getResultList();
    }

    public void cambiarEstadoPedido(Long pedidoId, String nuevoEstado) {
        em.getTransaction().begin();
        Pedido pedido = em.find(Pedido.class, pedidoId);
        if (pedido != null) {
            pedido.setEstado(nuevoEstado);
            em.merge(pedido);
        }
        em.getTransaction().commit();
    }

    public void priorizarPedido(Long pedidoId) {
        em.getTransaction().begin();
        Pedido pedido = em.find(Pedido.class, pedidoId);
        if (pedido != null) {
            pedido.setEstado("Prioritario");
            em.merge(pedido);
        }
        em.getTransaction().commit();
    }
}

