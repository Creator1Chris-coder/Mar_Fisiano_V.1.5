package com.cevicheria.cola;

import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.cevicheria.pedido.Pedido;

public class DashboardCocina {
    private ColaManager colaManager;

    public DashboardCocina() {
        this.colaManager = new ColaManager();
    }

    public void crearDashboard() {
        JFrame frame = new JFrame("Dashboard Cocina");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        List<Pedido> pedidos = colaManager.obtenerPedidosEnCola();
        for (Pedido pedido : pedidos) {
            JLabel label = new JLabel("Pedido ID: " + pedido.getId() + " - Estado: " + pedido.getEstado());
            panel.add(label);
        }

        frame.add(panel);
        frame.setVisible(true);
    }
}