package com.cevicheria.reporte;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.export.*;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import java.util.*;

public class ReporteExportar {

    public void exportarReportePDF(String jrxmlPath, String outputPath) {
        try {
            JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlPath);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap<>(), new JREmptyDataSource());

            JasperExportManager.exportReportToPdfFile(jasperPrint, outputPath);

            System.out.println("Reporte exportado exitosamente a PDF.");
        } catch (JRException e) {
            e.printStackTrace();
        }
    }

    public void exportarReporteExcel(String jrxmlPath, String outputPath) {
        try {
            JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlPath);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, new HashMap<>(), new JREmptyDataSource());

            JRXlsExporter exporter = new JRXlsExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputPath));
            exporter.exportReport();

            System.out.println("Reporte exportado exitosamente a Excel.");
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
}
