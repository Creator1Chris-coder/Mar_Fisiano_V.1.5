package com.cevicheria.reporte;

import java.util.List;

import jakarta.persistence.*;

import com.cevicheria.app.Producto;

public class ReportePopularidad {
    private EntityManager em;

    public ReportePopularidad() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public List<Producto> obtenerProductosMasPopulares() {
        String query = "SELECT p FROM Producto p ORDER BY (SELECT SUM(dp.cantidad) FROM DetallePedido dp WHERE dp.producto = p) DESC";
        return em.createQuery(query, Producto.class).setMaxResults(5).getResultList();
    }
}