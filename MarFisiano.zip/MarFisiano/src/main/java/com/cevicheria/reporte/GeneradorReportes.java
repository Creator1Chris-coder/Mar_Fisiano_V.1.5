package com.cevicheria.reporte;

import java.util.List;

import com.cevicheria.app.Producto;

public class GeneradorReportes {

    public void generarTodosLosReportes() {
        ReporteVentas reporteVentas = new ReporteVentas();
        reporteVentas.generarReporteVentas();

        ReportePopularidad reportePopularidad = new ReportePopularidad();
        List<Producto> productosPopulares = reportePopularidad.obtenerProductosMasPopulares();

        System.out.println("Top 5 productos más populares:");
        for (Producto producto : productosPopulares) {
            System.out.println(producto.getNombre());
        }
    }
}
