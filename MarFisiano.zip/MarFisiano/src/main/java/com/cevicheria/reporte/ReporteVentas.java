package com.cevicheria.reporte;

import java.util.HashMap;
import java.util.Map;

import net.sf.jasperreports.engine.*;

public class ReporteVentas {

    public void generarReporteVentas() {
        try {
            String jrxmlFile = "src/resources/reportes/ventas_diarias.jrxml";
            JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlFile);

            Map<String, Object> parameters = new HashMap<>();
            parameters.put("fecha_inicio", "2025-06-01");
            parameters.put("fecha_fin", "2025-06-30");

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());

            JasperExportManager.exportReportToPdfFile(jasperPrint, "src/resources/reportes/ventas_diarias.pdf");

            System.out.println("Reporte generado correctamente.");
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
}
