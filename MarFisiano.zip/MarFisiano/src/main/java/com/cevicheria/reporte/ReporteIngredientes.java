package com.cevicheria.reporte;

import java.util.List;

import com.cevicheria.inventario.Ingrediente;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

public class ReporteIngredientes {

    private EntityManager em;

    public ReporteIngredientes() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public List<Ingrediente> obtenerIngredientesMasUtilizados() {
        String query = "SELECT i FROM Ingrediente i ORDER BY (SELECT SUM(dp.cantidad) FROM DetallePedido dp WHERE dp.producto.id = i.id) DESC";
        return em.createQuery(query, Ingrediente.class).setMaxResults(5).getResultList();
    }
}
