package InventarioManager;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.cevicheria.inventario.Ingrediente;

public class InventarioForm {

    private InventarioManager inventarioManager;

    public InventarioForm() {
        this.inventarioManager = new InventarioManager();
    }

    public void crearFormularioInventario() {
        JFrame frame = new JFrame("Gestión de Inventario");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel nombreLabel = new JLabel("Ingrediente:");
        JTextField nombreField = new JTextField(20);
        JLabel cantidadLabel = new JLabel("Cantidad Actual:");
        JTextField cantidadField = new JTextField(5);
        JLabel cantidadMinimaLabel = new JLabel("Cantidad Mínima:");
        JTextField cantidadMinimaField = new JTextField(5);
        JLabel unidadLabel = new JLabel("Unidad:");
        JTextField unidadField = new JTextField(5);

        JButton agregarButton = new JButton("Agregar Ingrediente");

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                Double cantidad = Double.parseDouble(cantidadField.getText());
                Double cantidadMinima = Double.parseDouble(cantidadMinimaField.getText());
                String unidad = unidadField.getText();

                Ingrediente ingrediente = new Ingrediente();
                ingrediente.setNombre(nombre);
                ingrediente.setCantidadActual(cantidad);
                ingrediente.setCantidadMinima(cantidadMinima);
                ingrediente.setUnidad(unidad);

                inventarioManager.registrarEntradaIngrediente(ingrediente.getId(), cantidad);
                JOptionPane.showMessageDialog(frame, "Ingrediente agregado exitosamente.");
            }
        });

        frame.add(nombreLabel);
        frame.add(nombreField);
        frame.add(cantidadLabel);
        frame.add(cantidadField);
        frame.add(cantidadMinimaLabel);
        frame.add(cantidadMinimaField);
        frame.add(unidadLabel);
        frame.add(unidadField);
        frame.add(agregarButton);

        frame.setVisible(true);
    }
}
