package InventarioManager;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

import com.cevicheria.inventario.Ingrediente;

public class InventarioManager {
    private EntityManager em;

    public InventarioManager() {
        this.em = Persistence.createEntityManagerFactory("cevicheriaPU").createEntityManager();
    }

    public void registrarEntradaIngrediente(Long idIngrediente, Double cantidad) {
        em.getTransaction().begin();
        Ingrediente ingrediente = em.find(Ingrediente.class, idIngrediente);
        if (ingrediente != null) {
            ingrediente.setCantidadActual(ingrediente.getCantidadActual() + cantidad);
            em.merge(ingrediente);
        }
        em.getTransaction().commit();
    }

    public void registrarSalidaIngrediente(Long idIngrediente, Double cantidad) {
        em.getTransaction().begin();
        Ingrediente ingrediente = em.find(Ingrediente.class, idIngrediente);
        if (ingrediente != null) {
            ingrediente.setCantidadActual(ingrediente.getCantidadActual() - cantidad);
            em.merge(ingrediente);
        }
        em.getTransaction().commit();
    }
}
