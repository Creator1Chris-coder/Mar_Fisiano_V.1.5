package UsuarioForm;

import com.cevicheria.usuario.Autenticador;
import javax.swing.*;

public class UsuarioForm {
    private Autenticador autenticador;

    public UsuarioForm() {
        this.autenticador = new Autenticador();
    }

    public void crearFormularioLogin() {
        JFrame frame = new JFrame("Login");
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        JButton loginButton = new JButton("Iniciar sesión");
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (autenticador.autenticarUsuario(username, password)) {
                JOptionPane.showMessageDialog(frame, "Bienvenido!");
                frame.dispose(); 
            } else {
                JOptionPane.showMessageDialog(frame, "Credenciales incorrectas.");
            }
        });

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(loginButton);

        frame.add(panel);
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}